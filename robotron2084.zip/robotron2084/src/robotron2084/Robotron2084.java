package robotron2084;

public class Robotron2084 
{
	public static void main(String[] args)
	{
		GUI window = new GUI();
	}
}
