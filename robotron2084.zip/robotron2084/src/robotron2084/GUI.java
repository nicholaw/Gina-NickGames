package robotron2084;

import javax.swing.*;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import assets.ViewArea;
import java.awt.*;
import java.awt.event.*;

public class GUI extends JFrame implements ActionListener
{
	private ViewArea view;
	
	public GUI() 
	{
		view = new ViewArea();
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout());
		JButton redButton = new JButton("Red");
			redButton.addActionListener(this);
		JButton greenButton = new JButton("Green");
			greenButton.addActionListener(this);
		JButton yellowButton = new JButton("Yellow");
			yellowButton.addActionListener(this);
		buttonPanel.add(redButton);
		buttonPanel.add(greenButton);
		buttonPanel.add(yellowButton);
		
		//JFrame window = new JFrame();
		setLayout(new BorderLayout());
		add(view, BorderLayout.NORTH);
		add(buttonPanel, BorderLayout.SOUTH);
		pack();
		setLocationRelativeTo(null);
		setTitle("Robotron 2084");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		JButton source = (JButton)e.getSource();
		switch(source.getText())
		{
			case "Red":
				view.setDrawColor(Color.RED);
				break;
			case "Yellow":
				view.setDrawColor(Color.YELLOW);
				break;
			case "Green":
				view.setDrawColor(Color.GREEN);
				break;
			default:
				view.setDrawColor(Color.WHITE);
		}
		view.repaint();
	}
}
