package assets;

public class Robotron 
{
	private int x;
	private int y;
	
	public Robotron()
	{
		
	}
}
