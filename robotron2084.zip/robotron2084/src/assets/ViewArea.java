package assets;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color;

public class ViewArea extends Canvas
{
	private Color drawColor;
	
	public ViewArea()
	{
		drawColor = Color.white;
		setBackground(Color.black);
		setSize(550, 550);
	}
	
	public void setDrawColor(Color c)
	{
		drawColor = c;
	}
	
	@Override
	public void paint(Graphics g)
	{
		g.setColor(drawColor);
		g.fillRect(100, 250, 50, 50);
		int[] xCoord = {250, 275, 300}; int[] yCoord = {300, 250, 300};
		g.fillPolygon(xCoord, yCoord, 3);
		g.fillOval(400, 250, 50, 50);
	}
}
